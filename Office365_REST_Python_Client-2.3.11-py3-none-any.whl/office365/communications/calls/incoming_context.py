from office365.runtime.client_value import ClientValue


class IncomingContext(ClientValue):
    """Represents the context associated with an incoming call."""
    pass
