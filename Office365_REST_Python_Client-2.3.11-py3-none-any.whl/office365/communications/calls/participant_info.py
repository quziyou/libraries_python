from office365.runtime.client_value import ClientValue


class ParticipantInfo(ClientValue):
    """Contains additional properties about the participant identity"""
    pass
