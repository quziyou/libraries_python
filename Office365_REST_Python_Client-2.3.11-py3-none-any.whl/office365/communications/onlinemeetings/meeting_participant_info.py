from office365.runtime.client_value import ClientValue


class MeetingParticipantInfo(ClientValue):
    """Information about a participant in a meeting."""
    pass
