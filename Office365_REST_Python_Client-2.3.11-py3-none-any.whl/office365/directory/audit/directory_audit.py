from office365.entity import Entity


class DirectoryAudit(Entity):
    """Represents the directory audit items and its collection."""
    pass
