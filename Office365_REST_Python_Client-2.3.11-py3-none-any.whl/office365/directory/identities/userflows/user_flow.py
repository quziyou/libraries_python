from office365.entity import Entity


class IdentityUserFlow(Entity):
    pass
