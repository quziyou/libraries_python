from office365.directory.directory_object import DirectoryObject


class PolicyBase(DirectoryObject):
    pass
