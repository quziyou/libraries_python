from office365.runtime.client_value import ClientValue


class NumberColumn(ClientValue):
    """The numberColumn on a columnDefinition resource indicates that the column's values are numbers."""
    pass
