from office365.runtime.client_value import ClientValue


class SpecialFolder(ClientValue):
    """The SpecialFolder resource groups special folder-related data items into a single structure."""
    pass
