from office365.runtime.client_value import ClientValue


class Video(ClientValue):
    """The Video resource groups video-related data items into a single structure."""
    pass
