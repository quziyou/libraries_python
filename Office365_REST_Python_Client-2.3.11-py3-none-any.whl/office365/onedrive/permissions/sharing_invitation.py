from office365.runtime.client_value import ClientValue


class SharingInvitation(ClientValue):
    """The SharingInvitation resource groups invitation-related data items into a single structure."""
    pass
