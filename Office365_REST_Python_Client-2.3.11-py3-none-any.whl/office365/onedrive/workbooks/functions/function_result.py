from office365.entity import Entity


class WorkbookFunctionResult(Entity):
    pass
