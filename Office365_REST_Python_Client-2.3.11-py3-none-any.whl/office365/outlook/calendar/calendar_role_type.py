class CalendarRoleType:
    pass
