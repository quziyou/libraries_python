from office365.runtime.client_value import ClientValue


class ScheduleItem(ClientValue):
    pass
