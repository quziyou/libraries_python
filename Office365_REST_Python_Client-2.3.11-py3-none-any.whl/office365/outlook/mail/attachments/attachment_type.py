class AttachmentType:
    def __init__(self):
        pass

    file = "file"
    item = "item"
    reference = "reference"
