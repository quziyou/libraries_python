class Importance:
    def __init__(self):
        pass

    low = "low"
    normal = "normal"
    high = "high"
