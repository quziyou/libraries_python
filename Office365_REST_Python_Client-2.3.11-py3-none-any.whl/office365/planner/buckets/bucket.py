from office365.entity import Entity


class PlannerBucket(Entity):
    pass
