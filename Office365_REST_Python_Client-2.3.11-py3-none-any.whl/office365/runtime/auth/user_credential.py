class UserCredential(object):

    def __init__(self, user_name, password):
        """

        :type password: str
        :type user_name str
        """
        self.userName = user_name
        self.password = password
