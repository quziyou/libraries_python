class ODataParameter(object):
    pass
