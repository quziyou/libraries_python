class EntityType:

    def __init__(self):
        pass

    event = "0"
