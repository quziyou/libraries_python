from office365.runtime.client_value import ClientValue


class SearchHit(ClientValue):
    pass
