from office365.sharepoint.changes.change import Change


class ChangeFile(Change):
    pass
