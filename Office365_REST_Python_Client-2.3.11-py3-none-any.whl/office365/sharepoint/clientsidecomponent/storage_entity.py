from office365.sharepoint.base_entity import BaseEntity


class StorageEntity(BaseEntity):
    """Storage entities which are available across app catalog scopes."""
    pass
