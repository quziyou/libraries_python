from office365.runtime.client_value import ClientValue


class CustomActionElement(ClientValue):
    """A class specifies a custom action element."""
    pass
