from office365.sharepoint.base_entity import BaseEntity


class Feature(BaseEntity):
    """Represents an activated feature."""
    pass
