from office365.sharepoint.fields.field import Field


class FieldChoice(Field):
    """Represents a choice field control."""
