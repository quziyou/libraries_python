from office365.sharepoint.fields.field import Field


class FieldMultiChoice(Field):
    """Specifies a field (2) that contains one or more values from a set of specified values."""
    pass
