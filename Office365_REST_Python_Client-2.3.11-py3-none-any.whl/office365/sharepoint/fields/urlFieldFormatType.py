class UrlFieldFormatType:
    pass
