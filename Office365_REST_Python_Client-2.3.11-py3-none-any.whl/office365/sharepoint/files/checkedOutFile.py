from office365.sharepoint.base_entity import BaseEntity


class CheckedOutFile(BaseEntity):
    pass
