from office365.sharepoint.listitems.listitem import ListItem


class UserInfoItem(ListItem):
    pass
