class CustomizedPageStatus:
    """Specifies the customization (ghost) status of the SPFile."""
    pass
