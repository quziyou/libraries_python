from office365.sharepoint.base_entity import BaseEntity


class GroupService(BaseEntity):

    def get_group_image(self):
        pass
