from office365.runtime.client_object import ClientObject


class ClientSidePage(ClientObject):
    """Represents the data and methods associated with client side "modern" pages"""

    @staticmethod
    def from_file(file):
        return None
