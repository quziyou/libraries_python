from office365.sharepoint.base_entity import BaseEntity


class PrimaryCityTime(BaseEntity):
    pass
