from office365.sharepoint.publishing.site_page import SitePage


class RepostPage(SitePage):
    """"""
    pass
