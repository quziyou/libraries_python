from office365.sharepoint.base_entity import BaseEntity


class RichSharing(BaseEntity):
    pass
