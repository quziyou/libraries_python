from office365.runtime.client_value import ClientValue


class SitePageVersionInfo(ClientValue):
    pass
